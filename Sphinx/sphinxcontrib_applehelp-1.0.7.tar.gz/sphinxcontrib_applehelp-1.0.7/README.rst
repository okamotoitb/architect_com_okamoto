=======================
sphinxcontrib-applehelp
=======================

sphinxcontrib-applehelp is a sphinx extension which outputs Apple help books.

For more details, please visit http://www.sphinx-doc.org/.

Installing
==========

Install from PyPI::

   pip install -U sphinxcontrib-applehelp

Contributing
============

See `CONTRIBUTING.rst`__

.. __: https://github.com/sphinx-doc/sphinx/blob/master/CONTRIBUTING.rst
