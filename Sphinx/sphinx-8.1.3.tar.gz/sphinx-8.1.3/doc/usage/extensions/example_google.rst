:orphan:

.. _example_google:

Example Google Style Python Docstrings
======================================

.. seealso::

   :ref:`example_numpy`

.. only:: builder_html

   Download: :download:`example_google.py <example_google.py>`

.. literalinclude:: example_google.py
   :language: python
