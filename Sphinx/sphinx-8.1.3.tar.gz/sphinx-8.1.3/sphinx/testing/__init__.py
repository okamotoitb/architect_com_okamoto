"""Sphinx test utilities

You can require sphinx.testing pytest fixtures in a test module or a conftest
file like this:

   pytest_plugins = 'sphinx.testing.fixtures'
"""
