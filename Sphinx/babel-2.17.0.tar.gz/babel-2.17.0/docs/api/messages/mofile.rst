MO File Support
===============

.. module:: babel.messages.mofile

The MO file support can read and write MO files.  It reads them into
:class:`~babel.messages.catalog.Catalog` objects and also writes catalogs
out.

.. autofunction:: read_mo

.. autofunction:: write_mo
