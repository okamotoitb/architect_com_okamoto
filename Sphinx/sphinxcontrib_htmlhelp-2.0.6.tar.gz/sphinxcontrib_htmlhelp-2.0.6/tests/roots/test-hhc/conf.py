project = 'Python'
html_short_title = "Sphinx's documentation"
