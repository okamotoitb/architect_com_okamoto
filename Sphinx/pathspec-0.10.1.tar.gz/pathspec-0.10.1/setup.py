"""
This setup script only exists to support legacy installations where pip
is cumbersome be used such as for system packages.
"""

from setuptools import setup

setup()
